HDR Image was taken from:
http://www.hdri-hub.com/hdrishop/freesamples/freehdri/item/76-hdr-sky-cloudy

Released under Creative Commons Attribution 3.0 Unported License.


For rendering setup I've used allegorithmic guideline on Substance to unity workflow which can be found here:
https://support.allegorithmic.com/documentation/display/SPDOC/Unity+5